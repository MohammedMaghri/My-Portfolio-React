import React, { useState } from "react";
import "./Home.css"
import Navbar from "../../layouts/Nav/Navbj";
import About from "../About/About";

function Home()
{
    const [cursor, setCursor] = useState({ x: 0, y: 0 });

    const handleMouseMove = (event) => {
        setCursor({ x: event.clientX, y: event.clientY });
    };

    return (
        <div className="inside" onMouseMove={handleMouseMove} >
            {cursor && <div className="cursor-move" style={{ left: cursor.x, top: cursor.y }}>
                <div className="point"></div>
                </div>}
            <Navbar />
            <About/>
        </div>
    );
}

export default Home ;