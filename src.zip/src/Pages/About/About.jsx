import React, { useRef, useState } from "react";
import "./Ab.css"
import Me from "../../images/flags/me.jpeg"
import { motion } from "framer-motion";
import { ImHtmlFive } from "react-icons/im";
import { TbBrandJavascript } from "react-icons/tb";
import { SiCss3 } from "react-icons/si";
import { FaReact } from "react-icons/fa6";
import { TbLetterC } from "react-icons/tb";
import { VscTerminalBash } from "react-icons/vsc";
import { FaGithub } from "react-icons/fa";
import { FaLinkedinIn } from "react-icons/fa6";

const data = [
    {"value" : 61 , "icon" : <FaReact className="othericons" />} ,
    {"value" : 65, "icon" : <SiCss3 className="othericons"  /> },
    {"value" : 55, "icon" : <TbBrandJavascript className="othericons"  />},
    {"value" : 70, "icon" : <ImHtmlFive className="othericons"  />},
    {"value" : 77, "icon" : <TbLetterC className="othericons"  />},
    {"value" : 40, "icon" : <VscTerminalBash className="othericons"  />}
]

const other = [
    {"icon1" : <SiCss3 className="othericons" />, "icon2" : <FaReact className="othericons" />, "icon3" : <TbBrandJavascript className="othericons" />} ,
    {"icon1" : <ImHtmlFive className="othericons" />, "icon2" : <TbLetterC className="othericons" />, "icon3" : <VscTerminalBash className="othericons" />} ,
]

const FunctionUrlpass = (thisurl) =>{
    window.location.href = thisurl;
}
function Abou() {

    return (
        <div className="the">
            <div className="text-part">
                <div className="txt">
                    <div className="first">
                        <p>Hello I'm </p>
                    </div>
                    <div className="txttwo">
                        <p  >M.maghri</p>
                    </div>
                </div>
                <motion.div className="levels">
                        <div className="insi">
                            {
                                data.map((data, index) => (
                                    <div key={index} className="skillss">
                                        <div className="each"> {data.icon} </div>
                                        <div className="line" style={{ width: `${data.value}%` }}></div>
                                    </div>
                                ))
                            }
                        </div>
                    <div className="iconsinsides">
                        {
                            other.map((other, otherindex)=> (
                                <div className="twos">
                                    <div className="boxs"> {other.icon1} </div>
                                    <div className="boxs"> {other.icon2} </div>
                                    <div className="boxs"> {other.icon3} </div>
                                </div>
                            ))
                        }
                    </div>
                </motion.div>
            </div>
            <div className="image-part">
                <div className="settwo" >
                    <motion.div initial={{ y: -1000, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ type: "spring", stiffness: 10, duration: 5 }} className="img">
                        <motion.img transition={{ duration: 50 }} src={Me}></motion.img>
                    </motion.div>
                    <motion.div className="level">
                        {
                            data.map((data, index) => (
                                <div key={index} className="skills">
                                    <div className="each"> {data.icon} </div>
                                    <div className="line" style={{ width: `${data.value}%` }}></div>
                                </div>
                            ))
                        }
                        <div className="iconsinside">
                            {
                                other.map((other, otherindex)=> (
                                    <div className="two">
                                        <div className="box"> {other.icon1} </div>
                                        <div className="box"> {other.icon2} </div>
                                        <div className="box"> {other.icon3} </div>
                                    </div>
                                ))
                            }
                        </div>
                    </motion.div>
                </div>
            </div>
            <div className="Aboutme">
                <p> " Front-end developer with 2 years of experience and a CS student at 1337 School, specializing in responsive and dynamic web applications. " </p>
                <div className="iconsin">
                    <div className="boxicons"> <FaGithub onClick={() => FunctionUrlpass("https://github.com/MohammedMaghri")} className="ic" /> </div>
                    <div className="boxicons"> < FaLinkedinIn onClick={() => FunctionUrlpass("https://ma.linkedin.com/in/mohammed-maghri-63241329b/fr")} className="ic" /> </div>
                </div>
            </div>
        </div>
    );
}

export default Abou;