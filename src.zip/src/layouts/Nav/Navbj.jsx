import React, { useRef, useState } from "react";
import "./Navb.css";
import { FaConnectdevelop } from "react-icons/fa";
import { CiHome } from "react-icons/ci";
import { VscTypeHierarchy } from "react-icons/vsc";
import { SiGoogleforms } from "react-icons/si";
import { PiContactlessPayment } from "react-icons/pi";
import { MdWorkOutline } from "react-icons/md";
import { RxDragHandleHorizontal } from "react-icons/rx";
import { motion } from "framer-motion";


function Navbar()
{
    const [seter, setName] = useState(false);
    const [other, setSize] = useState(false);
    const Handle_click = (setit) => {
        setit((value)=> {
            if (value === false) value = true;
            else if (value === true) value = false;
            return (value);
        })
    };
    const [drag, setDrager] = useState(false);
    const Handleclick = (seter) =>
        { 
            seter((value) => {
                if (value === false) value = true ;
                else if (value === true) value = false;
                return (value);
            })
        } 
    const api_key = "AIzaSyBoj0huuOFlv9kvKND9Gt3jEbjAhJ9Bfi4";

    return (
        <motion.div initial={{y:-50, opacity:0}} animate={{y:0, opacity:1}} transition={{duration:1}} className="bar">
            <div className="name">
                <FaConnectdevelop className="twic" />
                <p> M.maghri </p>
            </div>
            <div className="selects">
                <div className="Home">
                    <CiHome className="marks" />
                    <p> Home </p>
                </div>
                <div className="Home">
                    <VscTypeHierarchy className="marks" />
                    <p> Service </p>
                </div>
                <div className="Home">
                    <SiGoogleforms className="marks" />
                    <p> Resume </p>
                </div>
                <div className="Home">
                    <MdWorkOutline className="marks" />
                    <p> Work </p>
                </div>
                <div className="Home">
                    <PiContactlessPayment className="marks" />
                    <p> Contact </p>
                </div>
            </div>
            <div className="hbut">
                <button className="hireme"  > Hire-Me</button>
            </div>
            <div className="drop-down">
                <RxDragHandleHorizontal  onClick={() => Handleclick(setDrager)} className="drag" />
                { drag && <div className="pop-up">
                    <div className="iconsin">
                        <CiHome className="marks" />
                        <p> Home </p>
                    </div>
                    <div className="iconsin">
                        <VscTypeHierarchy className="marks" />
                        <p> Service </p>
                    </div>
                    <div className="iconsin">
                        <SiGoogleforms className="marks" />
                        <p> Resume </p>
                    </div>
                    <div className="iconsin">
                        <MdWorkOutline className="marks" />
                        <p> Work </p>
                    </div>
                    <div className="iconsin">
                        <PiContactlessPayment className="marks" />
                        <p> Contact </p>
                    </div>
                </div> }
            </div>
        </motion.div>
    );
}
export default Navbar;